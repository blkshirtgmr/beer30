---
name: Obsidian Draught & Industrial Hospitality
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1c1b1d'
  surface-container: '#201f21'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#e8bcbb'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#ae8786'
  outline-variant: '#5e3f3e'
  surface-tint: '#ffb3b2'
  primary: '#ffb3b2'
  on-primary: '#680013'
  primary-container: '#ff525e'
  on-primary-container: '#5b0010'
  inverse-primary: '#bf002c'
  secondary: '#ffb955'
  on-secondary: '#452b00'
  secondary-container: '#dc9100'
  on-secondary-container: '#4f3100'
  tertiary: '#c7c5d5'
  on-tertiary: '#2f2f3b'
  tertiary-container: '#908f9e'
  on-tertiary-container: '#292935'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad9'
  primary-fixed-dim: '#ffb3b2'
  on-primary-fixed: '#410008'
  on-primary-fixed-variant: '#92001f'
  secondary-fixed: '#ffddb4'
  secondary-fixed-dim: '#ffb955'
  on-secondary-fixed: '#291800'
  on-secondary-fixed-variant: '#633f00'
  tertiary-fixed: '#e3e1f1'
  tertiary-fixed-dim: '#c7c5d5'
  on-tertiary-fixed: '#1a1b26'
  on-tertiary-fixed-variant: '#464652'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
---

## Brand & Style

This design system establishes an architectural, high-energy, and meticulously crafted digital atmosphere for a premier culinary and craft beverage destination. Moving away from weathered rustic tropes and neon dive clichés, the aesthetic fuses structural brutalist precision with luxurious tactile dark glassmorphism.

### Design Principles
- **Architectural Rigor:** Layouts and containers honor structural lines, hairline grid division, and engineered spacing reminiscent of modern steel-and-glass gastropub architecture.
- **Luminous Chiaroscuro:** Deep obsidian bases create absolute negative space against which precision crimson lasers and amber warmth capture optical focus.
- **Tactile Materiality:** Glass panels with muted inner reflections, brushed metallic strokes, and soft neon halos simulate late-night ambient interior lighting and draft machinery.
- **Direct & Confident:** Clear, authoritative typographic scale and decisive micro-interactions communicate culinary excellence and curation.

## Colors

The palette is engineered around deep obsidian black tones punctuated by a vivid neon crimson accent and golden malt secondary cues.

### Palette Tokens & Application
- **Primary Accent (`#FF1E44`):** Electric crimson used for primary calls-to-action, active tap selections, live event highlights, and key state badges. Emits a controlled glow effect when layered on obsidian surfaces.
- **Secondary Accent (`#F5A623`):** Warm amber/liquid gold allocated strictly for craft tap selections, barrel-aged highlights, tasting ratings, and secondary accents.
- **Base Neutral (`#0A0A0C`):** Absolute canvas background providing pitch-black depth.
- **Surface Neutrals:**
  - `Surface 1 (Base Container)`: `#121216`
  - `Surface 2 (Elevated Container)`: `#1A1A22`
  - `Surface Glass`: `rgba(18, 18, 22, 0.72)` with backdrop filtering.
- **Structural Borders (`#2A2A36` & `rgba(255, 255, 255, 0.08)`):** Hairline precision strokes that delineate sections, cards, and grid columns without visual clutter.
- **Typography:**
  - `Primary Text`: `#F4F4F6` (High-contrast pure off-white)
  - `Muted Text`: `#8E8E9F` (Cool structural grey)
  - `Subtle / Disabled`: `#4B4B5A`

## Typography

The type system blends structural authority with high legibility.

- **Headlines (`Space Grotesk`):** Engineered, tech-forward proportions with industrial punch. Used in uppercase for primary navigation and hero display titles to invoke tap handles, illuminated board menus, and architectural signage.
- **Body & Editorial Copy (`Plus Jakarta Sans`):** Smooth, highly readable grotesque sans with warm aperture geometries. Softens dense descriptions of brewing processes, tasting notes, and food pairings.
- **Labels & Monikers:** High-tracking uppercase labels using `Space Grotesk` provide tabular metadata clarity (e.g., ABV %, IBU, Brewery Origin, Table ID).

## Layout & Spacing

Layouts follow a modular 12-column architectural grid on desktop, transitioning to 6 columns on tablet, and a single cohesive stream on mobile (4 columns).

### Structure
- **Gutters & Margin Rules:** Margin whitespace creates a distinct frame around the canvas, referencing structural gallery and venue blueprints. Vertical dividers frequently use `1px solid rgba(255,255,255,0.06)` between columns to emphasize the steel framework.
- **Rhythm:** Spacing follows strict multiples of `4px` and `8px`. Dense data (e.g., tap listings, ABV counters, ingredient breakdowns) uses `space-xs` and `space-sm` for compact industrial density, while section headers leverage `space-xl` and `space-2xl` for breathing room.

## Elevation & Depth

Depth is rendered through translucent obsidian planes, hairline metallic edges, and localized neon luminescence rather than standard diffused drop shadows.

### Elevation Hierarchy
1. **Canvas (`#0A0A0C`):** Baseline void.
2. **Structural Panels (Level 1):** `background: rgba(18, 18, 22, 0.75)`, `backdrop-filter: blur(16px)`, surrounded by `1px solid rgba(255, 255, 255, 0.07)`.
3. **Floating Overlays & Modals (Level 2):** `background: rgba(26, 26, 34, 0.85)`, `backdrop-filter: blur(24px)`, `box-shadow: 0 16px 40px -10px rgba(0, 0, 0, 0.85)`. Border: `1px solid rgba(255, 255, 255, 0.12)`.
4. **Neon Accent Elevation (Active/Focused):** Critical touchpoints project a red light cast: `box-shadow: 0 0 24px -2px rgba(255, 30, 68, 0.35)`.
5. **Inner Specular Highlight:** Cards and actionable containers utilize an inset top-edge highlight (`box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.1)`) simulating overhead venue spotlights catching machined edges.

## Shapes

The roundedness token is set to `1` (Soft), yielding subtle `4px` base radii with `8px` (`rounded-lg`) for major surface modules.

- **Geometric Restraint:** Avoid oversized, pill-shaped bubbles or bubbly consumer curves. Retain tight, machined corners that mirror industrial brass, slate coasters, and milled steel bar fixtures.
- **Pills for Status Tags Only:** Fully rounded pill shapes (`border-radius: 9999px`) are strictly reserved for compact status indicators (e.g., "ON TAP", "LIMITED CASK", "SOLD OUT").

## Components

### Buttons
- **Primary:** Neon crimson background (`#FF1E44`), pure off-white bold uppercase text (`#FFFFFF`), subtle inset top border highlight, soft neon drop glow (`0 0 16px rgba(255, 30, 68, 0.3)`). Hover: scale `1.02` with amplified glow.
- **Secondary / Glass:** Translucent backdrop (`rgba(255, 255, 255, 0.04)`), hairline border (`rgba(255, 255, 255, 0.15)`), off-white text. Hover: border color shifts to `#FF1E44`, background shifts to `rgba(255, 30, 68, 0.08)`.
- **Text Action:** Space Grotesk uppercase with tracked spacing, paired with an industrial arrow glyph (`→`) that shifts right `4px` on hover.

### Menu & Tap Cards
- Constructed with glassmorphism surface styling (`rgba(18, 18, 22, 0.7)`), separated by `1px` metallic borders.
- Header block showcases Tap Number in high-contrast monospaced `Space Grotesk`, followed by beer name, style, ABV, and IBU metrics arranged in an engineered data grid.
- Hover reveals an amber edge highlight for craft reserves or crimson for signature selections.

### Inputs & Selectors
- Background: `#121216`. Hairline border: `#2A2A36`.
- Typography: Body-md in off-white; placeholder in `#4B4B5A`.
- Active/Focus: Border transitions immediately to `#FF1E44` with a minimal `0 0 0 1px #FF1E44` glow ring.

### Chips & Badges
- Compact tags with `Space Grotesk` uppercase font.
- Amber variant: `background: rgba(245, 166, 35, 0.1)`, `border: 1px solid rgba(245, 166, 35, 0.3)`, text `#F5A623`.
- Crimson variant: `background: rgba(255, 30, 68, 0.1)`, `border: 1px solid rgba(255, 30, 68, 0.3)`, text `#FF1E44`.

### Lists & Dividers
- Lists employ full-bleed hairline separation (`1px solid rgba(255, 255, 255, 0.06)`).
- Tap lists feature tabular alignment where price and volume are right-aligned in high-contrast numerical typography.